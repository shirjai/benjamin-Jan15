//
//  Refresh.h
//  bw3
//
//  Created by Ashish on 7/28/14.
//  Copyright (c) 2014 Ashish. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Cuboid.h"
#import "BwCuboid.h"

@interface Refresh : NSObject
-(Cuboid *) RefreshAPI:(int) TableId:(int) mode;


@end
