//
//  notesDetail.h
//  bw3
//
//  Created by Shirish Jaiswal on 10/14/14.
//  Copyright (c) 2014 Shirish Jaiswal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface notesDetail : UITextView

@property(nonatomic, readonly) NSLayoutManager *layoutManager;

@end
