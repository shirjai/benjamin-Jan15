//
//  intelligence.m
//  bw3
//
//  Created by Ashish on 5/5/14.
//  Copyright (c) 2014 Ashish. All rights reserved.
//

#import "intelligence.h"

@implementation intelligence

@end
