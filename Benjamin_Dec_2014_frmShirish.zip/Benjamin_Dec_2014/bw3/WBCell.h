//
//  WBCell.h
//  bw4
//
//  Created by Srinivas on 10/2/14.
//  Copyright (c) 2014 Ashish. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WBCell : NSObject

@property (copy,nonatomic) NSString *WorkbookName;
@property (copy,nonatomic) NSString *Desc;
@property (copy,nonatomic) NSString *LastRefresh;
@property (copy,nonatomic) NSString *lastSubmit;


@end
