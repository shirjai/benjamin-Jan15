//
//  WBCell.m
//  bw4
//
//  Created by Srinivas on 10/2/14.
//  Copyright (c) 2014 Ashish. All rights reserved.
//

#import "WBCell.h"

@implementation WBCell{
    
}

@end
