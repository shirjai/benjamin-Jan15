//
//  device.h
//  bw3
//
//  Created by Srinivas on 5/5/14.
//  Copyright (c) 2014 Ashish. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface device : NSObject

@end
