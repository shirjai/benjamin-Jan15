//
//  Submit.h
//  bw3
//
//  Created by Srinivas on 9/11/14.
//  Copyright (c) 2014 Ashish. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BwCuboid.h"
#import "Cuboid.h"

@interface Submit : NSObject

-(void)SubmitAPI: (Cuboid *)cub;

@end
