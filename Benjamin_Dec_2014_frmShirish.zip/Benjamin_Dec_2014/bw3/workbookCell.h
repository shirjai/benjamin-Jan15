//
//  workbookCell.h
//  bw4
//
//  Created by Srinivas on 10/3/14.
//  Copyright (c) 2014 Ashish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface workbookCell : UITableViewCell

@property(nonatomic,weak) IBOutlet UILabel *wbname;
@property(nonatomic,weak) IBOutlet UILabel *desc;

@end
