//
//  UserLogin.h
//  bw3
//
//  Created by Ashish on 4/28/14.
//  Copyright (c) 2014 Ashish. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserLogin : NSObject

-(NSString *)authenticateuser:(NSString *)user :(NSString *)pass;


@end
