//
//  watchCellViewController.h
//  collectionViewStudy
//
//  Created by Shirish Jaiswal on 11/3/14.
//  Copyright (c) 2014 shirish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface watchCellViewController : UICollectionViewCell

@property (nonatomic,strong) IBOutlet UILabel *cellLabel;

@end
